<?php

$LRSs = [
    [
        'endpoint' => '',
        'username' => '',
        'password' => '',
        'version'  => '1.0.1'
    ]
];
$KEYs = [
    'public' => 'path/to/keys/cacert.pem',
    'private' => 'path/to/keys/privkey.pem',
    'password' => null
];
